#!/bin/bash

if [ "$1" = "-help" ]; then
	echo "Uso: backup_full.sh <origen> <destino>"
	echo "Ejemplo: backup_full.sh /var/log /backup_dir"
	exit 0
fi

if [ $# -ne 2 ]; then
	echo "Faltan argumentos. Use -help"
	exit 1
fi

ORIGEN=${1%/}
DESTINO=${2%/}

if [ ! -d "$ORIGEN" ] || ! df "$ORIGEN"> /dev/null 2>&1; then
	echo "El origen no está disponible"
	exit 2
fi

if [ ! -d "$DESTINO" ] || ! df "$DESTINO"> /dev/null 2>&1; then
	echo "El destino no esta disponible"
	exit 3
fi

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
tar -czf "$DESTINO/${NOMBRE}_bkp_$FECHA.tar.gz" "$ORIGEN" 2> /dev/null && echo "Backup Ok" || echo "error en el backup"
