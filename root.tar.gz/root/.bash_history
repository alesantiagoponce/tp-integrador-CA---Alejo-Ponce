history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/resolv.conf v
powerofff
poweroff
sudo cat /etc/hash 
cd /usr/local/bin/
ls -ltr
ls -l
base64 -d -i < cat /etc/hash 
cat /etc/hash 
cat /etc/hash  > base64 -d -i
cat /etc/hash | base64 -d -i
rm /etc/hash 
chatrr -i /etc/hash 
cd /etc/
ls -l |has
ls -l |hash
ls -ltr 
chatrr +i hash 
chattr -i /etc/hash 
rm /etc/hash 
ls -l
reboot
history
shutdown now
vim /etc/hostname
vim/etc/hosts
vim/etc/hosts
vim /etc/hosts
hostnamectl set-hostname TPServer
exit
cat/etc/debianversion
cat /etc/debian_version
apt update
apt upgrade
apt autoremove
ip a
clear
ip a
ip r
clear
apt update
apt-update
apt update
clear
apt update
apt-cache search openssh-server
apt get install openssh-server
apt-get install openssh-server
clear
vim /etc/resolv.conf
apt update
ping -c 2 8.8.8.8
ping -c 2 deb.debian.org
vim /etc/apt/sources.list
apt update
apt upgrade
cat/etc/debian_version
clear
cat /etc/debian_version
apt-get install openssh-server
CLEAR
clear
vim /etc/ssh/ssh_config
vim /etc/ssh/sshd_config
vim /etc/ssh/sshd_config
vim /etc/ssh/sshd_config
vim /etc/ssh/sshd_config
vim /etc/ssh/sshd_config
clear
ssh-keygen
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
systemctl restart shh
systemctl restart ssh
systemctl status ssh
cat /root/.ssh/authorized_keys
clear
ip a
ip route
cat /etc/network/interfaces
vim /etc/network/interfaces
cat /etc/network/interfaces
reboot
ip a
ping -c 2 8.8.8.8
clear
ping -c 2 deb.debian.org
clear
apt install apache2 php libapache2-mod-php php-mysql -y
php -v
systemctl status apache2
q
clear
apt install mariadb-server -y
systemctl status mariadb
ls /root
less /root/db.sql
tar -tzf Material_Adicional_TPVMCA.tar.gz
tar -xzf Material_Adicional_TPVMCA.tar.gz
cp Material_Adicional_TPVMCA/* /root/
ls /root
less /root/db.sql
mysql -u root < /root/db.sql
mysql -u root -e "SHOW DATABASES;"
mysql -u root -e "SELECT * FROM ingenieria.alumnos;"
grep -i -E "mysqli|host|user|pass|localhost" /root/index.php
cat /root/clave_publica.pub >> /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys
poweroff
lsblk
fdisk /dev/sdc
lsblk /dev/sdc
mkfs -t ext4 /dev/sdc1
mkfs -t ext 4 /dev/sdc2
mkfs -t ext4 /dev/sdc2
poweroff
mkdir /www_dir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
vim /etc/fstab
vim /etc/fstab
umount /www_dir /backup_dir
mount -a
df -h
reboot
df -h
lsblk
blkid
cat /etc/fstab
vim /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sda1) /home ext4 rw,auto 0 0" >> /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdc1) /www_dir ext4 defaults 0 2" >> /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdc2) /backup_dir ext4 defaults 0 2" >> /etc/fstab
cat /etc/fstab
umount /www_dir /backup_dir
systemctl daemon-reload
mount -a
lsblk
reboot
lsblk
cat /proc/partitions > /opt/particion
cat /opt/particion
cp /root/index.php /root/logo.png /www_dir
chown -R www-data:www-data /www_dir
ls -l /www_dir
vim /etc/apache2/sites-available/000-default.conf
vim /etc/apache2/apache2.conf
vim /etc/apache2/apache2.conf
apache2ctl configtest
vim /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
poweroff
